package hibernate;

/**
 * 
 * @author Xincheng Yang
 * 
 * Session Factory is a factory pattern. (Factory pattern is a software design pattern)
 * In reality, the session factory is build based on database.
 * E.g., a OracleFactory or a MySQLFactory, extends SessionFactory(Or an abstract class).
 */
public abstract class SessionFactory {
	/**
	 * Here is a static method for build related session factory.
	 * @param cfg
	 * @return
	 */
	public static SessionFactory build(Configuration cfg) {
		return new MySqlSessionFactory(cfg);
	}
	
	/**
	 * 
	 * @param cfg
	 * @return SessionFactory
	 */
	public abstract Session openSession();
}
