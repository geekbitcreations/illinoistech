package groupproject.itmd515finalproject;

/*
Deborah Barndt
	 Thomas Boller
	 2-23-18
	 parseAndUpdage.java
	 Project Assignment 1
	This is a class used to act as main for testing our project assignment 1 files
*/


public class parseAndUpdate {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		XmlParser parse = new XmlParser();
		
		parse.parseDTXML();
		
		//DAO daoO = new DAO();
		
		//daoO.createTables();

		
		
	}

}
