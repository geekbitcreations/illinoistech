package grouplab.itmd515assign3;

/*
	Deborah Barndt
	3-8-18
	Consumer.java
	Programming Assignment 3
	This is program holds the Consumer class.
*/

public interface Consumer 
{
	void processMessages(String msg, String rec);
}
