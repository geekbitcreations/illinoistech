/** Deborah Barndt
 *  1-17-17
 *  MainActivity.java
 *  Lab 1
 *  This program creates a temperature converter android application. It will convert the input
 *  number from the user to either celsius or fahrenheit, change the color of the background
 *  depending on the temperature entered, and display an image if the temperature is above 90
 *  or below 0.
 *  Written by Deborah Barndt.
 */

package com.example.u2.tempconverter;

import android.graphics.Color;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.RadioButton;
import android.widget.ImageView;
import android.widget.Toast;
import android.view.View;
import android.widget.EditText;
import com.google.android.gms.appindexing.Action;
import com.google.android.gms.appindexing.AppIndex;
import com.google.android.gms.appindexing.Thing;
import com.google.android.gms.common.api.GoogleApiClient;

public class MainActivity extends AppCompatActivity
{
    private EditText text;

    // Create object to manipulate background color.
    View view;
    /**
     * ATTENTION: This was auto-generated to implement the App Indexing API.
     * See https://g.co/AppIndexing/AndroidStudio for more information.
     */

    // Create iv object to manipulate image view.
    ImageView iv;

    private GoogleApiClient client;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        text = (EditText) findViewById(R.id.editText);
        // ATTENTION: This was auto-generated to implement the App Indexing API.
        // See https://g.co/AppIndexing/AndroidStudio for more information.
        client = new GoogleApiClient.Builder(this).addApi(AppIndex.API).build();
    }

    /* This method is called when the user clicks the button and is handled
    because we assigned the name to the "OnClick property" of the button.
     */
    public void onClick(View view)
    {
        switch (view.getId())
        {
            case R.id.button:
                RadioButton celsiusButton = (RadioButton)
                        findViewById(R.id.radioButton1);
                RadioButton fahrenheitButton = (RadioButton)
                        findViewById(R.id.radioButton2);

                if (text.getText().length() == 0)
                {
                    Toast.makeText(this, "Please enter a valid number",
                            Toast.LENGTH_LONG).show();
                    return;
                }

                float inputValue = Float.parseFloat(text.getText().toString());

                if (celsiusButton.isChecked())
                {
                    text.setText(String.valueOf(ConverterUtil.convertCelsiusToFahrenheit(inputValue)));
                    celsiusButton.setChecked(false);
                    fahrenheitButton.setChecked(true);
                }

                else
                {
                    text.setText(String.valueOf(ConverterUtil.convertFahrenheitToCelsius(inputValue)));
                    fahrenheitButton.setChecked(false);
                    celsiusButton.setChecked(true);
                }

                // Grab current result value now in Text Field.
                inputValue = Float.parseFloat(text.getText().toString());
                view = findViewById(R.id.activity_main);
                iv = (ImageView) findViewById(R.id.imageView);

                if(inputValue > 90)
                {
                    // Set hex color to sky blue.
                    view.setBackgroundColor(Color.parseColor("#87CEFF"));

                    // Set the image visibility.
                    iv.setVisibility(View.VISIBLE);

                    // Clear any prior image.
                    ((ImageView) iv.findViewById(R.id.imageView)).setImageResource(0);

                    // Show sun on image.
                    iv.setImageResource(R.drawable.sun);
                }

                else if(inputValue < 0)
                {
                    // Set color to red.
                    //view.setBackgroundColor(Color.RED);

                    // Set hex color to sky blue.
                    view.setBackgroundColor(Color.parseColor("#B0171F"));

                    // Clear any prior image.
                    ((ImageView) iv.findViewById(R.id.imageView)).setImageResource(0);

                    // Show sun on image.
                    iv.setImageResource(R.drawable.snowman);
                }

                else
                {
                    // Set color to yellow.
                    view.setBackgroundColor(Color.YELLOW);

                    // Set the image visibility.
                    iv.setVisibility(View.INVISIBLE);

                    // Clear any prior image.
                    ((ImageView) iv.findViewById(R.id.imageView)).setImageResource(0);
                }

                break;
        }
    }

    /**
     * ATTENTION: This was auto-generated to implement the App Indexing API.
     * See https://g.co/AppIndexing/AndroidStudio for more information.
     */
    public Action getIndexApiAction() {
        Thing object = new Thing.Builder()
                .setName("Main Page") // TODO: Define a title for the content shown.
                // TODO: Make sure this auto-generated URL is correct.
                .setUrl(Uri.parse("http://[ENTER-YOUR-URL-HERE]"))
                .build();
        return new Action.Builder(Action.TYPE_VIEW)
                .setObject(object)
                .setActionStatus(Action.STATUS_TYPE_COMPLETED)
                .build();
    }

    @Override
    public void onStart() {
        super.onStart();

        // ATTENTION: This was auto-generated to implement the App Indexing API.
        // See https://g.co/AppIndexing/AndroidStudio for more information.
        client.connect();
        AppIndex.AppIndexApi.start(client, getIndexApiAction());
    }

    @Override
    public void onStop() {
        super.onStop();

        // ATTENTION: This was auto-generated to implement the App Indexing API.
        // See https://g.co/AppIndexing/AndroidStudio for more information.
        AppIndex.AppIndexApi.end(client, getIndexApiAction());
        client.disconnect();
    }
}
