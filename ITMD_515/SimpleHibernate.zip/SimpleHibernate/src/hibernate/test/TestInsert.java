package hibernate.test;

import entity.Student;
import hibernate.*;

public class TestInsert {
	public static void main(String[] args) {
		try {
			SessionFactory sf = Configuration.configure().buildSessionFactory();
			Session session = sf.openSession();
			
			Student s = new Student();
			s.setStudentId(3);
			s.setStudentName("Student3");
			session.insert(s);
			
			session.close();
			System.out.println("Save success!");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
