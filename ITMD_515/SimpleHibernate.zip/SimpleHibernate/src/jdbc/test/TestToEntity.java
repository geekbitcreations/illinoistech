package jdbc.test;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import entity.TeachAssistant;

public class TestToEntity {
	public static void main(String[] args) {
		String driver = "com.mysql.jdbc.Driver";
		String url = "jdbc:mysql://localhost:3306/testdb?useSSL=false";
		String dbName = "root";
		String dbPwd = "yxcroot";
		
		String sql = "SELECT * FROM TA"; 
		
		Connection conn = null;
		Statement statement = null;
		ResultSet result = null;
		ArrayList<TeachAssistant> list = new ArrayList<>();
		try {
			Class.forName(driver);
			conn = DriverManager.getConnection(url, dbName, dbPwd);
			
			statement = conn.createStatement();
			result = statement.executeQuery(sql);
			
			while(result.next()) {
				TeachAssistant s = new TeachAssistant();
				s.setId(result.getInt("id"));
				s.setName(result.getString("name"));
				list.add(s);
			}
			
			for(TeachAssistant s : list) {
				System.out.println(s.toString());
			}
			
			
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Query fail:" + e.getMessage());
		} finally {
			try {
				result.close();
				statement.close();
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

	}
}
