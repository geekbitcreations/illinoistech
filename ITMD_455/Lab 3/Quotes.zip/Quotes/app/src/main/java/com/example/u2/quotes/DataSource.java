package com.example.u2.quotes;

import java.util.ArrayList;

/** Deborah Barndt
 *  2-13-17
 *  DataSource.java
 *  Lab 3
 *  This program creates a list of quotes and the corresponding images to go with them.
 *  Written by Deborah Barndt.
 */

public class DataSource
{
    private ArrayList<Integer> mPhotoPool;
    private ArrayList<Integer> mQuotePool;
    private ArrayList<Integer> mPhotoHdPool;

    public ArrayList<Integer> getmPhotoHdPool()
    {
        return mPhotoHdPool;
    }

    public ArrayList<Integer> getmPhotoPool()
    {
        return mPhotoPool;
    }

    public ArrayList<Integer> getmQuotePool()
    {
        return mQuotePool;
    }

    private void setupPhotoPool()
    {
        mPhotoPool.add(R.drawable.steve_1);
        mPhotoPool.add(R.drawable.steve_2);
        mPhotoPool.add(R.drawable.steve_3);
        mPhotoPool.add(R.drawable.steve_4);
        mPhotoPool.add(R.drawable.mandela);
        mPhotoPool.add(R.drawable.audrey);
        mPhotoPool.add(R.drawable.einstein);
        mPhotoPool.add(R.drawable.rickman_2);
        mPhotoPool.add(R.drawable.angelou);
        mPhotoPool.add(R.drawable.einstein_2);
    }

    private void setupQuotePool()
    {
        mQuotePool.add(R.string.quote_1);
        mQuotePool.add(R.string.quote_2);
        mQuotePool.add(R.string.quote_3);
        mQuotePool.add(R.string.quote_4);
        mQuotePool.add(R.string.quote_5);
        mQuotePool.add(R.string.quote_6);
        mQuotePool.add(R.string.quote_7);
        mQuotePool.add(R.string.quote_8);
        mQuotePool.add(R.string.quote_9);
        mQuotePool.add(R.string.quote_10);
    }

    private void setupPhotoHDPool()
    {
        mPhotoHdPool.add(R.drawable.steve_hd_1);
        mPhotoHdPool.add(R.drawable.steve_hd_2);
        mPhotoHdPool.add(R.drawable.steve_hd_3);
        mPhotoHdPool.add(R.drawable.steve_hd_4);
        mPhotoHdPool.add(R.drawable.mandela_hd);
        mPhotoHdPool.add(R.drawable.hepburn_hd_2);
        mPhotoHdPool.add(R.drawable.einstein_hd_1);
        mPhotoHdPool.add(R.drawable.rickman_hd);
        mPhotoHdPool.add(R.drawable.angelou_hd);
        mPhotoHdPool.add(R.drawable.einstein_hd_2);
    }

    public int getDataSourceLength()
    {
        return mPhotoPool.size();
    }

    public DataSource()
    {
        mPhotoPool = new ArrayList();
        mQuotePool = new ArrayList();
        mPhotoHdPool = new ArrayList();

        setupPhotoPool();
        setupQuotePool();
        setupPhotoHDPool();
    }
}
