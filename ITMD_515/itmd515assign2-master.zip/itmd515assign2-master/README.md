# itmd515assign2

JSP-Servlet Processing

Develop an online application using JEE (jsp and servlets) that responds to a user requests via on-line forms. The application comprises of following parts:

1. The page “GetFormData.jsp” includes an html form with action set to "ValidateFormDate.jsp" and provides the following fields: 

Field	Constraint	Instructions
Customer Name	4 – 50 characters	Reject at client side any input that does confirm to constraint.
Use javascript or html5 tags.

Customer Social Security Number	xxx-xx-xxxx
11 total characters
9 digits and 2 dashes in the location shown above.	Reject at client side with a message.  Use javascript or html 5 tags.
Zip Code	1.	Follows US format for zip code validation:
 xxxxx-xxxx
	Use Validation Bean API to validate the zip code 
Customer Email Address	2.	Minimum 7 characters.
3.	Must be a valid email address.	Use Bean Validator at the server side
Street Address 	4 – 50 characters	Reuse validation from customer name
City	3 – 50 characters	Same as above (reuse code)
State	2 letters, must be a valid US state.	No validation required.  Use a drop down list for valid states.  (List can be in the html form or driven from a database)
		

1.	The page "ValidateFormDate.jsp" should validate the input as shown in the table above.  Any violation of the above processing rules should be reported back to user with a detailed message.
2.	If info is correct save data in a Session Object and forward the user to "ProcessCustomerDataRequest.jsp".
3.	Use a Servlet to look up the longitude and latitude for the customer’s address (Google API).
4.	The "ProcessCustomerDataRequest.jsp" simply display all entered information including longitude and latitude and a thank you message back to the user.
5.	You need to use a Validation Bean, Servlet, Google Map API and a JSP pages for the application.
6.	your form should have a decent look and feel and should use css for styling. 
7.	you need to use the session object from the request object OR use Session Bean to carry the state from page to page.
