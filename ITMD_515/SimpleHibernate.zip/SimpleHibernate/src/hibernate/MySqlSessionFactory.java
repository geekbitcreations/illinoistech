package hibernate;

import java.sql.Connection;
import java.sql.DriverManager;

public class MySqlSessionFactory extends SessionFactory {
	private Configuration cfg;

	public MySqlSessionFactory(Configuration cfg) {
		this.cfg = cfg;
	}

	@Override
	public Session openSession() {
		Session session = null;
		try {
			Class.forName(cfg.getDriver());
			Connection conn = DriverManager.getConnection(cfg.getUrl(), cfg.getName(), cfg.getPwd());
			session = new Session(conn);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return session;
	}
	
}
