/** Deborah Barndt
 *  2-13-17
 *  QuoteReaderActivity.java
 *  Lab 3
 *  This program creates a list view full of quotes. When the user clicks on a particular
 *  quote, they will be taken to a detail view of the full quote.
 *  Written by Deborah Barndt.
 */

package com.example.u2.quotes;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

public class QuoteReaderActivity extends AppCompatActivity
{
    public class QuoteAdapter extends BaseAdapter
    {
        // Returns the number of items present in the data set.
        @Override
        public int getCount()
        {
            return mDataSource.getDataSourceLength();
        }

        // Gets the data item associated with the specified position in the data set.
        @Override
        public Object getItem(int position)
        {
            return position;
        }

        // Gets the row id associated with the specified position.
        @Override
        public long getItemId(int position)
        {
            return position;
        }

        // This is used to get a view that displays the data at the specified position in
        // the data set.
        @Override
        public View getView(int position, View convertView, ViewGroup parent)
        {
            ImageView thumbnail;
            TextView quote;

            if(convertView == null)
            {
                convertView = mInflator.inflate(R.layout.list_item_layout, parent, false);
            }

            thumbnail = (ImageView) convertView.findViewById(R.id.thumb);

            thumbnail.setImageResource(mDataSource.getmPhotoPool().get(position));
                quote = (TextView) convertView.findViewById(R.id.text);
                quote.setText(mDataSource.getmQuotePool().get(position));

            return convertView;
        }

        private Context mContext;
        private LayoutInflater mInflator;
        private DataSource mDataSource;

        public QuoteAdapter(Context c)
        {
            mContext = c;
            mInflator = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            mDataSource = new DataSource();
        }
    }

    // Called when the activity is first created.
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quote_reader);

        ListView mListView = (ListView) findViewById(R.id.quotes_list);
        mListView.setAdapter(new QuoteAdapter(this));

        mListView.setOnItemClickListener(new AdapterView.OnItemClickListener()
        {
            @Override
            public void onItemClick(AdapterView arg0, View arg1, int position, long arg3)
            {
                Intent i = new Intent(QuoteReaderActivity.this, QuoteDetail.class);
                i.putExtra("position", position);
                startActivity(i);
            }
        });
    }


}
