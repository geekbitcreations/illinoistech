package hibernate;

/**
 * 
 * @author Xincheng Yang
 * A simple hibernate configuration files. 
 * In fact, Hibernate load the configuration from XML, for simply it, I just hard code it in a JAVA file.
 */
public class Configuration {
	private final String DRIVER = "com.mysql.jdbc.Driver";
	private final String URL = "jdbc:mysql://localhost:3306/testdb?useSSL=false";
	private final String NAME = "root";
	private final String PWD = "yxcroot";
	private boolean showSql = false;

	/**
	 * Create session factory based on the configuration. 
	 * I just implemented oracle session factory.
	 * See 'factory pattern' for detail.
	 * @return
	 */
	public SessionFactory buildSessionFactory() {
		// Here is how to choose session factory based on configuration.
		return SessionFactory.build(this);
	}
	
	public static Configuration configure() {
		return new Configuration();
	}

	public String getDriver() {
		return DRIVER;
	}
	public String getUrl() {
		return URL;
	}
	public String getName() {
		return NAME;
	}
	public String getPwd() {
		return PWD;
	}
	public boolean isShowSql() {
		return showSql;
	}
	public void setShowSql(boolean showSql) {
		this.showSql = showSql;
	}
	
}
