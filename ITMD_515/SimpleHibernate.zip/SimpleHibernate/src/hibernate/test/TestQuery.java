package hibernate.test;

import entity.Student;
import hibernate.Configuration;
import hibernate.Session;
import hibernate.SessionFactory;

public class TestQuery {

	public static void main(String[] args) {
		try {
			SessionFactory sf = Configuration.configure().buildSessionFactory();
			Session session = sf.openSession();
			
			Student s = new Student();
			s.setStudentId(1);
			Student result = session.queryByPrimaryKey(s);
			
			if(result != null) {
				System.out.println(result.toString());
			} else {
				System.out.println("No result");
			}
			
			session.close();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
