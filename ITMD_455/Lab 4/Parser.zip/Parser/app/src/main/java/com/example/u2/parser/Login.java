/** Deborah Barndt
 *  2-26-17
 *  Login.java
 *  Lab 4
 *  This program creates a login screen and will do SAX xml parsing.
 *  Written by Deborah Barndt.
 */

package com.example.u2.parser;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class Login extends AppCompatActivity
{
    Button button1, button2;
    EditText username, password;

    TextView text1;
    int counter = 3;

    //EditText username = (EditText)findViewById(R.id.editText);
    //EditText password = (EditText)findViewById(R.id.editText3);

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        button1 = (Button)findViewById(R.id.button);
        username = (EditText)findViewById(R.id.editText);
        password = (EditText)findViewById(R.id.editText3);

        button2 = (Button)findViewById(R.id.button2);
        text1 = (TextView)findViewById(R.id.textView2);
        text1.setVisibility(View.GONE);

        final Context context = this;

        // OnClick Listener for the login button to go to the main activity screen, and the cancel button to close the app.
        button1.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                // Enter the correct password.
                if (username.getText().toString().equals("admin") && password.getText().toString().equals("admin"))
                {
                    Toast.makeText(getApplicationContext(), "Redirecting...", Toast.LENGTH_LONG).show();

                    final Intent intent = new Intent(context, MainActivity.class);
                    startActivity(intent);
                    //addListenerOnButton();
                }

                // Enter the wrong password.
                else
                {
                    Toast.makeText(getApplicationContext(), "Wrong Credentials", Toast.LENGTH_LONG).show();

                    text1.setVisibility(View.VISIBLE);
                    text1.setBackgroundColor(Color.TRANSPARENT);
                    counter--;
                    text1.setText(Integer.toString(counter));

                    // Disable the button and close the application.
                    if (counter == 0)
                    {
                        button1.setEnabled(false);
                    }
                }
            }
        });

        button2.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                finish();
            }
        });
    }

    // Method to activate the login button to go to the main activity screen.
    /*public void addListenerOnButton()
    {
        final Context context = this;
        button1 = (Button)findViewById(R.id.button);
        button1.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                final Intent intent = new Intent(context, MainActivity.class);
                startActivity(intent);
            }
        });
    }*/
}
