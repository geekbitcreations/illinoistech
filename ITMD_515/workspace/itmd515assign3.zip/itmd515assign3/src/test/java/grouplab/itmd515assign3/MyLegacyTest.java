package grouplab.itmd515assign3;

/*
	Deborah Barndt
	3-8-18
	MyLegacyTest.java
	Programming Assignment 3
	This is program holds the MyLegacyTest class.
*/

public class MyLegacyTest 
{
	public static void main(String[] args)
	{
		MyApplication app = new MyApplication();
		app.processMessages("Hi Deborah", "dbarndt@hawk.iit.edu");
	}
}
