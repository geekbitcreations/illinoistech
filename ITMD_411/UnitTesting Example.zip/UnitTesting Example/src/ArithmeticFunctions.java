public class ArithmeticFunctions {
	public int sub(int a, int b) {
		return a - b;
	}

	public int mult(int a, int b) {
		return a * b;
	}

	public int add(int a, int b) {
		return a + b;
	}

	public double div(int a, int b) {
		if (b != 0) {
			System.out.println("b cannot be 0");
			return 0.0;
		} else {
			return a / b;
		}

	}
}
