/** Deborah Barndt
 *  2-26-17
 *  XMLGetterSetters.java
 *  Lab 4
 *  This program creates the setters and getters for the SAX XML Parser.
 *  Written by Deborah Barndt.
 */

package com.example.u2.parser;

import android.util.Log;

import java.util.ArrayList;

/**
 * Created by U53R on 3/15/2017.
 */

public class XMLGettersSetters
{
    private ArrayList<String> title = new ArrayList<String>();
    private ArrayList<String> artist = new ArrayList<String>();
    private ArrayList<String> country = new ArrayList<String>();
    private ArrayList<String> company = new ArrayList<String>();
    private ArrayList<String> price = new ArrayList<String>();
    private ArrayList<String> year = new ArrayList<String>();
    private ArrayList<String> CD = new ArrayList<String>();

    // Getter method to get the variable company.
    public ArrayList<String> getCompany()
    {
        return company;
    }

    // Setter method to set the variable company.
    public void setCompany(String company)
    {
        this.company.add(company);
        Log.i("This is the company: ", company);
    }

    // Getter method to get the variable price.
    public ArrayList<String> getPrice()
    {
        return price;
    }

    // Setter method to set the variable price.
    public void setPrice(String price)
    {
        this.price.add(price);
        Log.i("This is the price: " , price);
    }

    // Getter method to get the variable year.
    public ArrayList<String> getYear()
    {
        return year;
    }

    // Setter method to set the variable year.
    public void setYear(String year)
    {
        this.year.add(year);
        Log.i("This is the year: ", year);
    }

    // Getter method to get the variable title.
    public ArrayList<String> getTitle()
    {
        return title;
    }

    // Setter method to set the variable title.
    public void setTitle(String title)
    {
        this.title.add(title);
        Log.i("This is the title: ", title);
    }

    // Getter method to get the variable artist.
    public ArrayList<String> getArtist()
    {
        return artist;
    }

    // Setter method to set the variable artist.
    public void setArtist(String artist)
    {
        this.artist.add(artist);
        Log.i("This is the artist: ", artist);
    }

    // Getter method to get the variable country.
    public ArrayList<String> getCountry()
    {
        return country;
    }

    // Setter method to set the variable country.
    public void setCountry(String country)
    {
        this.country.add(country);
        Log.i("This is the country: ", country);
    }

    // Getter method to get the variable attr.
    public ArrayList<String> getCD()
    {
        return CD;
    }

    // Setter method to set the variable attr.
    public void setAttribute(String attr)
    {
        this.CD.add(attr);
        Log.i("Sold out: ", attr);
    }
}
