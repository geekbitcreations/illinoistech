import static org.junit.Assert.*;

import org.junit.Test;

public class SampleTestCase {
	ArithmeticFunctions functions = new ArithmeticFunctions();
	ArithmeticFunctions functions1;
	
	@Test
	public void test() {
		assertEquals("Addition of 5 and 7 is 12", 12, functions.add(5, 7));
	}

	@Test
	public void testForSub() {
		assertEquals("Subtraction of 5 and 7 is 2", 2, functions.sub(5, 7));
	}
	@Test
	public void testForNull(){
		assertNull("Null value found" , functions1);
	}
	//students: test again for null value given functions1.add()
	
	//students: create an assert to test for div by zero!
	
	
	
}
