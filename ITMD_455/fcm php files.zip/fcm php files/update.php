<?php 

	$host='127.0.0.1';
	$uname='fcmuser';
	$pwd='fcmpass';
	$db="fcm";

	$con = mysql_connect($host,$uname,$pwd) or die("connection failed");
	mysql_select_db($db,$con) or die("db selection failed");
	 
	$Token=$_REQUEST['Token'];
	$uname=$_REQUEST['uname'];
	 
	$flag['code']=0;
	 
	if($r=mysql_query("UPDATE users SET uname = '$uname' WHERE Token ='$Token'",$con))
	{
		$flag['code']=1;
	}
	 
	print(json_encode($flag));
	mysqli_close($con);

 ?>
