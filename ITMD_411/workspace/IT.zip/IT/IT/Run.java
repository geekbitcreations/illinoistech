package IT;

public class Run 
{

	public static void main(String[] args) throws Exception
	{
		HelpDesk hd = new HelpDesk();
		HelpDesk.createTable();
	}
}
