package hibernate.test;

import entity.Student;
import hibernate.*;

public class TestUpdate {
	public static void main(String[] args) {
		try {
			SessionFactory sf = Configuration.configure().buildSessionFactory();
			Session session = sf.openSession();
			
			// Because 1 already exist.
			Student s = new Student();
			s.setStudentId(1);
			s.setStudentName("Prof. Omar");
			session.update(s);
			
			session.close();
			System.out.println("Save success!");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
