/** Deborah Barndt
 *  2-13-17
 *  Splash.java
 *  Lab 3
 *  This program creates a splash screen to run before the main activity.
 *  Written by Deborah Barndt.
 */

package com.example.u2.quotes;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;

/**
 * Created by U2 on 2/14/2017.
 */

public class Splash extends Activity
{
    // Splash screen timer.
    private static int SPLASH_TIME_OUT = 5000;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        new Handler().postDelayed(new Runnable()
        {
            // Showing the splash screen with a timer.
            @Override
            public void run()
            {
                // This method will be executed once the timer is over, and will start the main
                // activity.
                Intent i = new Intent(Splash.this, QuoteReaderActivity.class);
                startActivity(i);

                // Close this activity.
                finish();
            }
        }, SPLASH_TIME_OUT);
    }
}
