<?php 

	if (isset($_POST["Token"]) && isset($_POST["uname"]) ) {
		
		   $_uv_Token=$_POST["Token"];
		   $_uv_uname=$_POST["uname"];
		   $conn = mysqli_connect("localhost","fcmuser","fcmpass","fcm") or die("Error connecting");

		   $q="INSERT INTO users (Token, uname) VALUES ( '$_uv_Token' , '$_uv_uname' ) "
              ." ON DUPLICATE KEY UPDATE Token = '$_uv_Token';";
              
      mysqli_query($conn,$q) or die(mysqli_error($conn));

      mysqli_close($conn);

	}


 ?>
 