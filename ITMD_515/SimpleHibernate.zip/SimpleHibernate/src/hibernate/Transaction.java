package hibernate;

import java.sql.Connection;
import java.sql.SQLException;

/**
 *
 * @author Xincheng Yang
 * 
 * Transaction is a class for Transaction in database.
 * 
 * Here I have commit and rollback for a transaction.
 *
 */
public class Transaction {
	private Connection conn;
	
	public Transaction(Connection conn) {
		try {
			// Turn off connection auto commit.
			conn.setAutoCommit(false);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		this.conn = conn;
	}
	
	public void commit() {
		try {
			conn.commit();
			conn.setAutoCommit(true);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public void rollback() {
		try {
			conn.rollback();
			conn.setAutoCommit(true);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

}
