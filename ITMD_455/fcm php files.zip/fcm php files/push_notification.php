<?php 

	function send_notification ($tokens, $message)
	{
		$url = 'https://fcm.googleapis.com/fcm/send';
		$fields = array(
			 'registration_ids' => $tokens,
			 'data' => $message
			);

		$headers = array(
			'Authorization:key = AAAAOOxYhRU:APA91bHCa1LeYzA4fsQv2i1-4XF-x443ENk2yBDnK2Z3PhCGcOtGuzIjdz4T-L0Xl5UUSnD2kaWZ1woIr4R4ItLKi6VKWxfKt6rd7vG1yv33ZJg1nwo5LEFmnNLXvcABZw_uKz7pmJNv',
			'Content-Type: application/json'
			);

	   $ch = curl_init();
       curl_setopt($ch, CURLOPT_URL, $url);
       curl_setopt($ch, CURLOPT_POST, true);
       curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
       curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
       curl_setopt ($ch, CURLOPT_SSL_VERIFYHOST, 0);  
       curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
       curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));
       $result = curl_exec($ch);           
       if ($result === FALSE) {
           die('Curl failed: ' . curl_error($ch));
       }
       curl_close($ch);
       return $result;
	}
	$conn = mysqli_connect("localhost","fcmuser","fcmpass","fcm");

    $option = isset($_POST['to_user']) ? $_POST['to_user'] : false;
   	
	$sql = " Select Token From users where uname = '$option'";

	$result = mysqli_query($conn,$sql);
	$tokens = array();

	if(mysqli_num_rows($result) > 0 ){

		while ($row = mysqli_fetch_assoc($result)) {
			$tokens[] = $row["Token"];
		}
	}

	mysqli_close($conn);
    
    $pushMessage = $_POST['message'];
    if(isset($pushMessage)) {

    $message = array("message" => $pushMessage);
	$message_status = send_notification($tokens, $message);
	echo $message_status;
	}
 ?>
<html>
<head>
 <title>FCM - PapaBase messaging service</title>
 <link rel="stylesheet" type="text/css" href="styles.css">
</head>
<body>
   <form method = 'POST' action = 'push_notification.php'>
    
    <h1 align='center'><img src="fbimg.png" alt="FB icon" style="width:32px;height:44px;">
     FCM - PapaBase messaging service</h1>
 
    <h3>Push Notification Admin Panel</h3>
     Current Registered users: 
        
	<select name="to_user">
	<option value="pick">Select User</option>
	<?php
	$conn = mysqli_connect("localhost","fcmuser","fcmpass","fcm");
	$sql = mysqli_query($conn, "SELECT uname From users");
	$row = mysqli_num_rows($sql);
	while ($row = mysqli_fetch_array($sql)){
	 echo "<option value='". $row['uname'] ."'>" .$row['uname'] ."</option>" ;
    }
	mysqli_close($conn);
	?>
	</select>
    <div>
      <br /> 
      <textarea rows = "3" name = "message" cols = "75" placeholder = "Type message here"></textarea>
    </div>
 	<div>
 	 <br /> 
     <input type = "submit" value = "Send Notification">
    </div>
   </form>
</body>
</html>
