/** Deborah Barndt
 *  2-26-17
 *  XMLHandler.java
 *  Lab 4
 *  This program creates the handlers for the SAX XML Parser.
 *  Written by Deborah Barndt.
 */

package com.example.u2.parser;

import android.util.Log;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

/**
 * Created by U53R on 3/15/2017.
 */

public class XMLHandler extends DefaultHandler
{
    String elementValue = null;
    Boolean elementOn = false;
    public static XMLGettersSetters data = null;

    public static XMLGettersSetters getXMLData()
    {
        return data;
    }

    public static void setXMLData(XMLGettersSetters data)
    {
        XMLHandler.data = data;
    }

    // This will be called when the tags of the XML starts.
    @Override
    public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException
    {
        elementOn = true;

        if(localName.equals("CATALOG"))
        {
            data = new XMLGettersSetters();
        }

        //else if(localName.equals("CD") && attributes.equals("yes"))
        else if(localName.equals("CD"))
        {
            try
            {
                String attributeValue = attributes.getValue("attr");
                data.setAttribute(attributeValue);
            }

            catch(Exception e)
            {
                Log.i("err on handler ", e.getMessage());
            }
        }
    }

    // This will be called when the tags of the XML end.
    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException
    {
        elementOn = false;

        // Sets the values after retrieving the values from the XML tags.
        if(localName.equalsIgnoreCase("title"))
            data.setTitle(elementValue);

        else if(localName.equalsIgnoreCase("artist"))
            data.setArtist(elementValue);

        else if(localName.equalsIgnoreCase("country"))
            data.setCountry(elementValue);

        else if(localName.equalsIgnoreCase("company"))
            data.setCompany(elementValue);

        else if(localName.equalsIgnoreCase("price"))
            data.setPrice(elementValue);

        else if(localName.equalsIgnoreCase("year"))
            data.setYear(elementValue);

        /*else if(localName.equalsIgnoreCase("yes"))
            data.setAttribute(elementValue);*/
    }

    // This is called to get the tags value.
    @Override
    public void characters(char[] ch, int start, int length) throws SAXException
    {
        if(elementOn)
        {
            elementValue = new String (ch, start, length);
            elementOn = false;
        }
    }
}
