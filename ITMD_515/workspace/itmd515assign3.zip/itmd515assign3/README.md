# itmd515assign3

See Slides titled: 08 -  Annotation-Reflection-DI 

https://www.journaldev.com/2394/java-dependency-injection-design-pattern-example-tutorial

complete the Injector Classes and build the complete project (submit a complete application)

In other words run through the tutorial and complete it and program it locally on your machine.
