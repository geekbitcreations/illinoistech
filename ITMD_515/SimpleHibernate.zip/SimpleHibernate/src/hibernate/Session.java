package hibernate;
import java.lang.reflect.Field;
import java.sql.*;

import hibernate.annotation.*;


/**
 * @author Xincheng Yang
 * 
 * Session is a wrapper for connection. 
 * Since I did not implement the connection pool or something, so each Session is a JDBC Connection.
 * 
 * I also added some function which is not supported by Hibernate.
 *
 */
public class Session {
	private Connection conn;
	
	public Session(Connection conn) {
		this.conn = conn;
	}
	
	public Transaction beginTransaction() {
		return new Transaction(conn);
	}
	
	@SuppressWarnings("unchecked")
	public <T> T queryByPrimaryKey(T obj)  throws Exception {
		String sql = "SELECT * FROM %s WHERE %s=?";
		Field primaryKey = DataMapping.mapPrimaryKey(obj);
		Field[] list = obj.getClass().getDeclaredFields();
		
		sql = String.format(sql, 
				DataMapping.mapEntity(obj), 
				DataMapping.mapColumn(primaryKey));
		PreparedStatement ps = conn.prepareStatement(sql);
		DataMapping.mapSetData(ps, 1, primaryKey, obj);
		ResultSet result = ps.executeQuery();
		
		if(result.next()) {
			T hit = (T) obj.getClass().newInstance();
			for(Field f : list) {
				DataMapping.mapGetData(result, f, hit);
			}
			return hit;
		}
		return null;
	}
	
	public <T> int save(T obj) throws Exception{
		T hit = queryByPrimaryKey(obj);
		if(hit == null) {
			return insert(obj);
		} else {
			return update(obj);
		}
	}
	
	public <T> int insert(T obj) throws Exception {
		Field[] fields = obj.getClass().getDeclaredFields();
		int index = 0;
		
		StringBuffer prefix = new StringBuffer("INSERT INTO "
				+ DataMapping.mapEntity(obj) + "(");
		StringBuffer suffix = new StringBuffer();
		for(Field f : fields) {
//			if(f.getAnnotation(GeneratedValue.class) == null) {
				prefix.append(DataMapping.mapColumn(f) + ", ");
				suffix.append("?, ");
//			}
		}
		// Remove the last ','
		prefix = new StringBuffer(prefix.substring(0, prefix.lastIndexOf(",")));
		prefix.append(") VALUES (");
		prefix.append(suffix.substring(0, suffix.lastIndexOf(",")));
		prefix.append(")");
		
		PreparedStatement ps = conn.prepareStatement(prefix.toString());
		for (int i = 0; i < fields.length; i++) {
//			if(fields[i].getAnnotation(GeneratedValue.class) == null) {
				DataMapping.mapSetData(ps, ++index, fields[i], obj);
//			}
		}
		
		int rv = ps.executeUpdate();
		ps.close();
		return rv;
	}
	
	public <T> int delete(T obj) throws Exception {
		String sql = "DELETE FROM %s WHERE %s=?";
		Field primaryKey = DataMapping.mapPrimaryKey(obj);
		
		sql = String.format(sql, 
				DataMapping.mapEntity(obj), 
				DataMapping.mapColumn(primaryKey));
		
		PreparedStatement ps = conn.prepareStatement(sql);
		DataMapping.mapSetData(ps, 1, primaryKey, obj);
		int rv =  ps.executeUpdate();
		ps.close();
		return rv;
	}
	
	public <T> int update(T obj) throws Exception {
		StringBuffer sql = new StringBuffer("UPDATE " + DataMapping.mapEntity(obj) + " SET ");
		
		Field[] fields = obj.getClass().getDeclaredFields();
		Field primaryKey = DataMapping.mapPrimaryKey(obj);
		int index = 0;

		for(Field f : fields) {
			if(!f.equals(primaryKey)) {
				sql.append(String.format(" %s=?,", DataMapping.mapColumn(f)));
			}
		}
		sql = new StringBuffer(sql.substring(0, sql.lastIndexOf(",")));
		sql.append(String.format(" WHERE %s=?", DataMapping.mapColumn(primaryKey)));
		
		PreparedStatement ps = conn.prepareStatement(sql.toString());
		for (int i = 0; i < fields.length; i++) {
			Field f = fields[i];
			if(!f.equals(primaryKey)) {
				DataMapping.mapSetData(ps, ++index, f, obj);
			}
		}
		DataMapping.mapSetData(ps, ++index, primaryKey, obj);
		int rv = ps.executeUpdate();
		ps.close();
		return rv;
	}
	
	public void close() {
		try {
			this.conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}
