package grouplab.itmd515assign3;

/*
	Deborah Barndt
	3-8-18
	EmailService.java
	Programming Assignment 3
	This is program holds the EmailService class.
*/

public class EmailService 
{
	public void sendEmail(String message, String receiver)
	{
		// Logic to send email.
		System.out.println("Email sent to " + receiver + " with Message = " + message + "!");
	}
}
