/** Deborah Barndt
 *  4-12-17
 *  Book.java
 *  Lab 7
 *  This program will provide the getters/setters from a derived book object.
 *  Written by Deborah Barndt.
 */

package com.example.u2.bookreviews;

/**
 * Created by U2 on 3/30/2017.
 */

public class Book
{
    private int id;
    private String title;
    private String author;
    private String rating;

    public Book()
    {

    }

    public Book(String title, String author)
    {
        super();
        this.title = title;
        this.author = author;
    }

    // Getter method to get the variable id.
    public int getId()
    {
        return id;
    }

    // Setter method to set the variable id.
    public void setId(int id)
    {
        this.id = id;
    }

    // Getter method to get the variable title.
    public String getTitle()
    {
        return title;
    }

    // Setter method to set the variable title.
    public void setTitle(String title)
    {
        this.title = title;
    }

    // Getter method to get the variable author.
    public String getAuthor()
    {
        return author;
    }

    // Setter method to set the variable author.
    public void setAuthor(String author)
    {
        this.author = author;
    }

    // Getter method to get the variable rating.
    public String getRating()
    {
        return rating;
    }

    // Setter method to set the variable rating.
    public void setRating(String rating)
    {
        this.rating = rating;
    }

    @Override
    public String toString()
    {
        return "Book [id=" + id + ", title=" + title + ", author=" + author
                + ", rating=" + rating + "]";
    }
}
