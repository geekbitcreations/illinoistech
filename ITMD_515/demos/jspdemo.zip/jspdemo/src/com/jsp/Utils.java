package com.jsp;

public class Utils {

	public static String makeItLower(String data)
	{
		return data.toLowerCase();
		
	}
	
}
