package hibernate.test;

import entity.Student;
import hibernate.*;

public class TestTransaction {
	public static void main(String[] args) {
		try {
			SessionFactory sf = Configuration.configure().buildSessionFactory();
			Session session = sf.openSession();
			
			Transaction tx = session.beginTransaction();
			for (int i = 100; i < 200; i++) {
				Student s = new Student();
				s.setStudentId(i);
				s.setStudentName("Student" + i);
				session.save(s);
			}
			tx.commit();
			
			session.close();
			System.out.println("Transaction success!");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
