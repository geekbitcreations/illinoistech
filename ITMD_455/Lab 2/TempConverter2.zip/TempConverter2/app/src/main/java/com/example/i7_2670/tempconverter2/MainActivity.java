/** Deborah Barndt
 *  1-31-17
 *  MainActivity.java
 *  Lab 2
 *  This program creates a temperature converter android application. It will convert the number
 *  selected on the seekbar to fahrenheit, display the 5 day forecast to the user when they
 *  select the checkbox, and go back to the original activity when the user hits the back button.
 *  Written by Deborah Barndt.
 */

package com.example.i7_2670.tempconverter2;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.ViewStub;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.SeekBar;
import android.widget.SeekBar.OnSeekBarChangeListener;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity
{
    // Declare seekbar object.
    SeekBar seekBar;

    // Declare textview object.
    TextView textView;

    // Declare member variables for seekbar.
    int discrete = 0;
    int start = 50;

    // Progress tracker.
    int start_position = 50;

    int temp = 0;

    // Declare objects for viewstub.
    ViewStub stub;
    CheckBox checkBox;

    // Declare listview object.
    ListView lv;

    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Declare viewstub object.
        stub = (ViewStub) findViewById(R.id.viewStub1);
        @SuppressWarnings("unused")
        View inflated = stub.inflate();
        stub.setVisibility(View.INVISIBLE);

        // ViewStub logic.
        checkBox = (CheckBox) findViewById(R.id.checkbox1);

        // Handle checkbox click event.
        checkBox.setOnCheckedChangeListener(new CheckBox.OnCheckedChangeListener()
        {
            public void onCheckedChanged(CompoundButton arg0, boolean isChecked)
            {
                if(isChecked)
                {
                    // Remove objects from parent view to allow for child view.
                    checkBox.setVisibility(View.GONE);
                    seekBar.setVisibility(View.GONE);
                    textView.setVisibility(View.GONE);
                    findViewById(R.id.textView2).setVisibility(View.GONE);

                    stub.setVisibility(View.VISIBLE);
                }
            }
        });

        // Seekbar logic.
        textView = (TextView) findViewById(R.id.textview);
        final TextView textView2;
        textView2 = (TextView) findViewById(R.id.textView2);

        // Set default view.
        textView.setText("    Celsius at 0°");
        seekBar = (SeekBar) findViewById(R.id.seekbar);
        seekBar.setProgress(start_position);

        // Create event handler for seekbar.
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener()
        {
            @Override
            public void onStopTrackingTouch(SeekBar seekBar)
            {
                // For the initial view result.
                if(temp == 0)
                {
                    /*Toast.makeText(getBaseContext(), "Fahrenheit result 32°",
                            Toast.LENGTH_SHORT).show();*/
                    textView2.setText("Fahrenheit result 32°");

                    // Set the textview visibility.
                    textView2.setVisibility(View.VISIBLE);
                }

                else
                {
                    /*Toast.makeText(getBaseContext(), "Fahrenheit result "
                            + String.valueOf(discrete) + "°", Toast.LENGTH_SHORT).show();*/
                    textView2.setText("Fahrenheit result " + String.valueOf(discrete) + "°");

                    // Set the textview visibility.
                    textView2.setVisibility(View.VISIBLE);
                }

            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar)
            {
                // TODO Auto-generated method stub.
            }

            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser)
            {
                // To convert progress passed as discrete (Fahrenheit) value.
                temp = progress-start;

                // Convert Celsius to Fahrenheit temp.
                discrete = (int) Math.round((((temp * 9.0) / 5.0) + 32));
                textView.setText("   Celsius at " + temp + "°");
            }
        });

        // ImageButton logic.
        ImageButton imageButton = (ImageButton)this.findViewById(R.id.imageButton);
        imageButton.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                finish();
            }
        });

        // Handle imageButton click event.
        imageButton.setOnClickListener(new View.OnClickListener()
        {
            @Override
                public void onClick(View v)
            {
                // Remove objects from child view to allow for parent view.
                checkBox.setVisibility(View.VISIBLE);
                seekBar.setVisibility(View.VISIBLE);
                textView.setVisibility(View.VISIBLE);
                findViewById(R.id.textView2).setVisibility(View.VISIBLE);
                checkBox.setChecked(false);

                stub.setVisibility(View.GONE);
            }
        });

        // Listview logic.
        String[] wkTemps = new String[] {"Monday Feb 6: 35°/32°",
                "Tuesday Feb 7: 41°/27°", "Wednesday Feb 8: 28°/14°",
                "Thursday Feb 9: 21°/13°", "Friday Feb 10: 26°/22°"};

        lv = (ListView) findViewById(R.id.listView);
        @SuppressWarnings({"unchecked", "rawtypes"})

        /**
         * To use a basic ArrayAdapter, you just need to initialize the adapter and attach
         * the adapter to the ListView. First, initialize the adapter.
        **/
        ArrayAdapter adapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1,
                android.R.id.text1, wkTemps);

        // Assign adapter to ListView.
        lv.setAdapter(adapter);
    }
}
