package jdbc.test;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class TestQuery {
	public static void main(String[] args) {
		String driver = "com.mysql.jdbc.Driver";
		String url = "jdbc:mysql://localhost:3306/testdb?useSSL=false";
		String dbName = "root";
		String dbPwd = "yxcroot";
		
		String sql = "SELECT * FROM TA"; 
		
		Connection conn = null;
		Statement statement = null;
		ResultSet result = null;
		try {
			Class.forName(driver);
			conn = DriverManager.getConnection(url, dbName, dbPwd);
			
			statement = conn.createStatement();
			result = statement.executeQuery(sql);
			System.out.println("Rows: " + result.getRow());
			System.out.println("Columns: " + result.getMetaData().getColumnCount());
			System.out.println("Data:");
			while(result.next()) {
				String str = String.format("  id=%d, name=%s", result.getInt(1), result.getString(2));
				System.out.println(str);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Query fail:" + e.getMessage());
		} finally {
			try {
				result.close();
				statement.close();
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			} catch (NullPointerException e) {
				
			}
		}

	}
}
