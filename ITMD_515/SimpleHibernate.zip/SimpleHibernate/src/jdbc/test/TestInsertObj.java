package jdbc.test;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;

import entity.TeachAssistant;

public class TestInsertObj {
	public static void main(String[] args) {
		String driver = "com.mysql.jdbc.Driver";
		String url = "jdbc:mysql://localhost:3306/testdb?useSSL=false";
		String dbName = "root";
		String dbPwd = "yxcroot";
		
		TeachAssistant ta = new TeachAssistant();
		ta.setId(3);
		ta.setName("Mike");

		Connection conn = null;
		PreparedStatement statement = null;
		try {
			Class.forName(driver);
			conn = DriverManager.getConnection(url, dbName, dbPwd);
			
			String sql = "INSERT INTO TA(id, name) values(?, ?)";
			statement = conn.prepareStatement(sql);
			statement.setInt(1, ta.getId());
			statement.setString(2, ta.getName());
			statement.executeUpdate();
			
			System.out.println("Insert Successfull.");
		} catch (Exception e) {
			System.out.println("Insert fail:" + e.getMessage());
		} finally {
			try {
				statement.close();
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

	}
}
