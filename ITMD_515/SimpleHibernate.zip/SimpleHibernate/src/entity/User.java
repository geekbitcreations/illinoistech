package entity;

import java.io.Serializable;

import hibernate.annotation.*;

@Entity(name = "sysuser")
public class User implements Serializable{
	
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue
    private Long id;
	
	@Column(name = "username", nullable = false)
    private String uname;
	
    private String password;
    
    public User(){
    	super();
    }
    
    public User(String uname, String pwd) {
    	super();
    	this.uname = uname;
    	this.password = pwd;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public void setUsername(String username) {
        this.uname = username;
    }

	public String getUsername() {
		return this.uname;
	}

    public void setPassword(String password) {
        this.password = password;
    }

	public String getPassword() {
		return this.password;
	}
}