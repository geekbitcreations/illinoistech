package entity;

import hibernate.annotation.*;

@Entity	
public class Student {
	@Id
	@Column(name="id")
	private int studentId;
	@Column(name="name", nullable = false)
	private String studentName;
	
	public int getStudentId() {
		return studentId;
	}

	public void setStudentId(int studentId) {
		this.studentId = studentId;
	}

	public String getStudentName() {
		return studentName;
	}

	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}

	@Override
	public String toString() {
		return "StudentId:" + this.studentId + ", StudentName:" + this.studentName;
	}
}
