
public abstract class Students {
abstract void read();
abstract void process();
abstract void print();
}
