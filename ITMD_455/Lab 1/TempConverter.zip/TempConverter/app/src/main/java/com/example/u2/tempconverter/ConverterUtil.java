/** Deborah Barndt
 *  1-17-17
 *  ConverterUtil.java
 *  Lab 1
 *  This program creates a temperature converter class that will convert the given input
 *  temperature to celsius or fahrenheit.
 *  Written by Deborah Barndt.
 */

package com.example.u2.tempconverter;

/**
 * Created by U2 on 1/17/2017.
 * Created by Deborah Barndt on 1/17/2017.
 */

public class ConverterUtil
{
    /**
     * @param fahrenheit
     * @return
     */
    // Converts to celsius
    public static double convertFahrenheitToCelsius(float fahrenheit)
    {
        return ((fahrenheit - 32) * 5.0 / 9.0);
    }

    /**
     * @param celsius
     * @return
     */
    // Converts to fahrenheit
    public static double convertCelsiusToFahrenheit(float celsius)
    {
        return (celsius * (9 / 5.0)) + 32;
    }
}
