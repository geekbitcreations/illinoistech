package hibernate.test;

import java.lang.annotation.Annotation;
import java.lang.reflect.Field;

import entity.Student;

public class TestAnnotation {

	public static void main(String[] args) {
		Student s = new Student();
		Field[] list = s.getClass().getDeclaredFields();
		for(Field f : list) {
			System.out.println(f.getName());
			for(Annotation a : f.getDeclaredAnnotations()) {
				System.out.print(a.toString() + "; ");
			}
			System.out.println();
		}
	}

}
