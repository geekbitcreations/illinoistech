package com.jsp;

import javax.annotation.ManagedBean;

@ManagedBean
public class UserBean
{
    public static String myString()
    {
          return "Welcome ";
    }
}