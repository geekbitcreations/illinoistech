package hibernate;

import java.lang.reflect.Field;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import hibernate.annotation.Column;
import hibernate.annotation.Entity;
import hibernate.annotation.Id;

public class DataMapping {
	
	public static void mapGetData(ResultSet rs, Field f, Object entity) throws SQLException, IllegalArgumentException, IllegalAccessException {
		f.setAccessible(true);
		if(f.getType().equals(java.sql.Date.class)) {
			f.set(entity, rs.getDate(mapColumn(f)));
		} else if(f.getType().equals(String.class)) {
			f.set(entity, rs.getString(mapColumn(f)));
		} else {
			f.set(entity, rs.getObject(mapColumn(f)));
		}
	}
	
	public static void mapSetData(PreparedStatement ps, int index, Field f, Object entity) throws SQLException, IllegalArgumentException, IllegalAccessException {
		f.setAccessible(true);
		if(f.getType().equals(java.sql.Date.class)) {
			ps.setDate(index, (java.sql.Date) f.get(entity));
		} else if(f.getType().equals(java.util.Date.class)) {
			ps.setDate(index, toSqlDate((java.util.Date) f.get(entity)));
		} else if(f.getType().equals(String.class)){
			ps.setString(index, (String)f.get(entity));
		} else {
			ps.setObject(index, f.get(entity));
		}
	}
	
	public static String mapEntity(Object entity) {
		Entity annotation = entity.getClass().getAnnotation(Entity.class);
		String name = null;
		if(annotation != null) {
			name = annotation.name();
		} 
		if(name == null || name.trim().equals("")) {
			name = entity.getClass().getSimpleName();
		}
		return name;
	}
	
	public static String mapColumn(Field f) {
		Column annotation = f.getAnnotation(Column.class);
		String name = null;
		if(annotation != null) {
			name = annotation.name();
		} 
		if(name == null || name.trim().equals("")) {
			name = f.getName();
		}
		return name;
	}
	
	public static Field mapPrimaryKey(Object entity) {
		Field[] list = entity.getClass().getDeclaredFields();
		for(Field f : list) {
			if(f.getAnnotation(Id.class) != null) {
				f.setAccessible(true);
				return f;
			}
		}
		return list[0];
	}

	public static java.sql.Date toSqlDate(java.util.Date o){
		java.util.Date date = o;
		return new java.sql.Date(date.getTime());
	}
}
