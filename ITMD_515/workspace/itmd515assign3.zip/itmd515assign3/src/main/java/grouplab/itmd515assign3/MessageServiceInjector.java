package grouplab.itmd515assign3;

/*
	Deborah Barndt
	3-8-18
	MessageServiceInjector.java
	Programming Assignment 3
	This is program holds the MessageServiceInjector class.
*/

public interface MessageServiceInjector 
{
	public Consumer getConsumer();
}
