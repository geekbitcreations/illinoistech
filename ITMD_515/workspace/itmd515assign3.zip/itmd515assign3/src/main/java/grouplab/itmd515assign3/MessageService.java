package grouplab.itmd515assign3;

/*
	Deborah Barndt
	3-8-18
	MessageService.java
	Programming Assignment 3
	This is program holds the MessageService class.
*/

public interface MessageService 
{
	void sendMessage(String msg, String rec);
}
