package jdbc.test;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class TestInsert {
	public static void main(String[] args) {
		String driver = "com.mysql.jdbc.Driver";
		String url = "jdbc:mysql://localhost:3306/testdb?useSSL=false";
		String dbName = "root";
		String dbPwd = "yxcroot";
		
		String sql1 = "INSERT INTO TA(id, name) values(1, 'Xincheng')";
		String sql2 = "INSERT INTO TA(id, name) values(2, 'Bingyu')";
		
		Connection conn = null;
		Statement statement = null;
		try {
			Class.forName(driver);
			conn = DriverManager.getConnection(url, dbName, dbPwd);
			
			statement = conn.createStatement();
			statement.executeUpdate(sql1);
			statement.executeUpdate(sql2);
			
			System.out.println("Insert Successfull.");
		} catch (Exception e) {
			System.out.println("Insert fail:" + e.getMessage());
		} finally {
			try {
				statement.close();
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

	}
}
