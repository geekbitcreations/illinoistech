/** Deborah Barndt
 *  4-12-17
 *  MainActivity.java
 *  Lab 7
 *  This program creates will run through standing operations of creating, reading, updating,
 *  and deleting from a database.
 *  Written by Deborah Barndt.
 */

package com.example.u2.bookreviews;

import android.nfc.Tag;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity
{
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        int total = 0;

        Log.d("Book", "Deborah Barndt");

        SqlHelper db = new SqlHelper(this);

        // Crud operations start here.
        // Add books.
        //db.addBook(new Book("ITMD 455: Lab 6", "Deborah Barndt"));
        //db.addBook(new Book("Android Studio Development Essentials", "Neil Smyth"));
        //db.addBook(new Book("Beginning Android Application Development", "Wei-Meng Lee"));
        //db.addBook(new Book("Programming Android", "Wallace Jackson"));
        //db.addBook(new Book("Hello, Android", "Wallace Jackson"));

        // Get all the books.
        List<Book> list = db.getAllBooks();

        // Update one book.
        int j = db.updateBook(list.get(3), "Hello, Android", "Ben Jackson");

        // Delete one book.
        //db.deleteBook(list.get(0));

        // Get all the books.
        db.getAllBooks();

        ListView listContent = (ListView) findViewById(R.id.list);
        list = new ArrayList<Book>();
        list = db.getAllBooks();

        // Get data from the table by the ListAdapter.
        ListAdapter customAdapter = new ListAdapter(this, R.layout.itemlistrow, list);
        listContent.setAdapter(customAdapter);

        // Get count of all books.
        db.getIds(total);

        // Print total number of books in the Logcat file.
        //Log.d("Books", "Total Books: " + total);
    }
}
