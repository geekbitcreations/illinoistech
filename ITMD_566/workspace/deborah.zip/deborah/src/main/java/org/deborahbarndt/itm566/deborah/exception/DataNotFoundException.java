package org.deborahbarndt.itm566.deborah.exception;

public class DataNotFoundException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = -7469924331506995248L;

	public DataNotFoundException(String message) {
		super(message);
	}
	
}
