package lab2;

public class Customer
{
    public String name;
    public String SSN;
    
    public Customer(String n, String ssn)
    {
        this.name = n;
        this.SSN = ssn;
    }
}
